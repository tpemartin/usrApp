card(
  categoryname="臺北大學城",
  title="【USR】社科院USR專書出版-「大學責任與高齡學習」",
  imgUrl ="https://miro.medium.com/max/1400/1*2v4yO6cR2XOSlI65Ge6GrA.jpeg"
) |> browseTag2()
